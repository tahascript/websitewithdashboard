-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 22 Eyl 2019, 12:44:02
-- Sunucu sürümü: 10.4.6-MariaDB
-- PHP Sürümü: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `tahascript_net`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `afis`
--

CREATE TABLE `afis` (
  `afis_id` int(11) NOT NULL,
  `afis_resim` varchar(250) NOT NULL,
  `afis_resim2` varchar(250) NOT NULL,
  `afis_baslik` varchar(250) NOT NULL,
  `afis_icerik` varchar(300) NOT NULL,
  `afis_buton_yazi` varchar(250) NOT NULL,
  `afis_buton_link` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `afis`
--

INSERT INTO `afis` (`afis_id`, `afis_resim`, `afis_resim2`, `afis_baslik`, `afis_icerik`, `afis_buton_yazi`, `afis_buton_link`) VALUES
(1, 'img/about/2.jpg', '', 'BİZİMLE ÇALIŞIN', 'WEB TASARIMCISI, WEB GELİŞTİRİCİSİ, SEO UZMANI, SOSYAL MEDYA YÖNETİCİSİ GİBİ DALLARDAN BİRİNDE ÇALIŞMIŞ, 1 YILDAN FAZLA DENEYİMİ OLAN ELEMANLAR ARANIYOR', 'BİZİMLE İLETİŞİME GEÇİN', '#contact');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `altbilgi`
--

CREATE TABLE `altbilgi` (
  `altbilgi_id` int(11) NOT NULL,
  `altbilgi_resim` varchar(250) NOT NULL,
  `altbilgi_icerik` text NOT NULL,
  `altbilgi_vizyon` text NOT NULL,
  `altbilgi_misyon` text NOT NULL,
  `altbilgi_facebook` varchar(250) NOT NULL,
  `altbilgi_twitter` varchar(250) NOT NULL,
  `altbilgi_instagram` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `altbilgi`
--

INSERT INTO `altbilgi` (`altbilgi_id`, `altbilgi_resim`, `altbilgi_icerik`, `altbilgi_vizyon`, `altbilgi_misyon`, `altbilgi_facebook`, `altbilgi_twitter`, `altbilgi_instagram`) VALUES
(1, 'img/27727302212129730397logo-black.png', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus tincidunt velit turpis, non pulvinar ipsum sagittis nec. Aenean et aliquet magna. Etiam sit amet ipsum ut urna faucibus porta. Proin at aliquet enim.</p>\r\n', '<h3>VİZYONUMUZ</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus tincidunt velit turpis, non pulvinar ipsum sagittis nec. Aenean et aliquet magna. Etiam sit amet ipsum ut urna faucibus porta. Proin at aliquet enim.</p>\r\n', '<h3>MİSYONUMUZ</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus tincidunt velit turpis, non pulvinar ipsum sagittis nec. Aenean et aliquet magna. Etiam sit amet ipsum ut urna faucibus porta. Proin at aliquet enim.</p>\r\n', '#', '#', '#');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE `ayarlar` (
  `id` int(11) NOT NULL,
  `site_logo` varchar(250) NOT NULL,
  `site_baslik` varchar(250) NOT NULL,
  `site_aciklama` varchar(400) NOT NULL,
  `site_anahtar_kelimeler` varchar(499) NOT NULL,
  `site_sahip` varchar(300) NOT NULL,
  `yonetim_tema` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `site_logo`, `site_baslik`, `site_aciklama`, `site_anahtar_kelimeler`, `site_sahip`, `yonetim_tema`) VALUES
(1, 'img/25675259652056720395logo.png', 'TahaScript &Uuml;cretsiz Y&ouml;netim Panelli Web Site Script', 'TahaScript &Uuml;cretsiz Y&ouml;netim Panelli Web Site Script', 'anahtar, kelimeler, buraya, gelmeli', 'Taha Script', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `form`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `adsoyad` varchar(250) NOT NULL,
  `eposta` varchar(250) NOT NULL,
  `konu` varchar(250) NOT NULL,
  `mesaj` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `form`
--

INSERT INTO `form` (`id`, `adsoyad`, `eposta`, `konu`, `mesaj`) VALUES
(2, 'Test', 'test@test.test', 'Test', 'test, test, test, test, test, test, test, test,'),
(3, 'Deneme', 'deneme@deneme.deneme', 'Deneme', 'Deneme, deneme, deneme, deneme, deneme, deneme, deneme, deneme'),
(5, 'Test', 'test@test.test', 'Test', 'test, test, test, test, test, test, test, test,'),
(6, 'Beta', 'Beta@Beta.Beta', 'Beta', 'BetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetaBetav'),
(7, 'Ahmet', 'Ahmet@ahmet.ahmet', 'Ahmet', 'Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, Ahmet, ');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

CREATE TABLE `hakkimizda` (
  `hakkimizda_id` int(11) NOT NULL,
  `hakkimizda_baslik` varchar(100) NOT NULL,
  `hakkimizda_icerik` text NOT NULL,
  `hakkimizda_resim` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`hakkimizda_id`, `hakkimizda_baslik`, `hakkimizda_icerik`, `hakkimizda_resim`) VALUES
(1, 'Hakkımızda Başlığı', '<h3>Hakkımızda Başlığı 2</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus tincidunt velit turpis, non pulvinar ipsum sagittis nec. Aenean et aliquet magna. Etiam sit amet ipsum ut urna faucibus porta. Proin at aliquet enim.</p>\r\n', 'img/270272277022677293161.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmetlerimiz`
--

CREATE TABLE `hizmetlerimiz` (
  `hizmetlerimiz_id` int(11) NOT NULL,
  `hizmetlerimiz_icon` varchar(100) NOT NULL,
  `hizmetlerimiz_baslik` varchar(250) NOT NULL,
  `hizmetlerimiz_icerik` text NOT NULL,
  `hizmetlerimiz_sira` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `hizmetlerimiz`
--

INSERT INTO `hizmetlerimiz` (`hizmetlerimiz_id`, `hizmetlerimiz_icon`, `hizmetlerimiz_baslik`, `hizmetlerimiz_icerik`, `hizmetlerimiz_sira`) VALUES
(2, 'fa fa-code', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İ&ccedil;eriğini Buraya Eklemeniz Gerekmektedir', 1),
(3, 'fa fa-camera-retro', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İ&ccedil;eriğini Buraya Eklemeniz Gerekmektedir', 2),
(4, 'fa fa-users', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İçeriğini Buraya Eklemeniz Gerekmektedir', 3),
(5, 'fa fa-camera-retro', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İçeriğini Buraya Eklemeniz Gerekmektedir', 4),
(6, 'fa fa-check', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İçeriğini Buraya Eklemeniz Gerekmektedir', 5),
(7, 'fa fa-car', 'Hizmet Başlığı', 'Eklediğiniz Hizmetin İ&ccedil;eriğini Buraya Eklemeniz Gerekmektedir', 6);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ilaveler`
--

CREATE TABLE `ilaveler` (
  `ilaveler_id` int(11) NOT NULL,
  `ilaveler_hizmetlerimiz_baslik` varchar(250) NOT NULL,
  `ilaveler_takimimiz_baslik` varchar(250) NOT NULL,
  `ilaveler_portfoy_baslik` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ilaveler`
--

INSERT INTO `ilaveler` (`ilaveler_id`, `ilaveler_hizmetlerimiz_baslik`, `ilaveler_takimimiz_baslik`, `ilaveler_portfoy_baslik`) VALUES
(1, 'Hizmetlerimiz', 'Takımımız', 'Portf&ouml;y');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim`
--

CREATE TABLE `iletisim` (
  `iletisim_id` int(11) NOT NULL,
  `iletisim_baslik` varchar(100) NOT NULL,
  `iletisim_telefon` text NOT NULL,
  `iletisim_mail` text NOT NULL,
  `iletisim_adres` text NOT NULL,
  `iletisim_harita` varchar(450) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `iletisim`
--

INSERT INTO `iletisim` (`iletisim_id`, `iletisim_baslik`, `iletisim_telefon`, `iletisim_mail`, `iletisim_adres`, `iletisim_harita`) VALUES
(1, 'Bizimle İletişime Ge&ccedil;in', '<p>Call: +1 5589 55488 55<br />\r\nMonday-Friday (9am-5pm)</p>\r\n', '<p>Email: info@example.com<br />\r\nWeb: www.example.com</p>\r\n', '<p>Location: A108 Adam Street<br />\r\nNY 535022, USA</p>\r\n', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22864.11283411948!2d-73.96468908098944!3d40.630720240038435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbg!4v1540447494452');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `kullanici_id` int(11) NOT NULL,
  `kullanici_resim` varchar(250) NOT NULL,
  `kullanici_isim` varchar(250) NOT NULL,
  `kullanici_mail` varchar(250) NOT NULL,
  `kullanici_sifre` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`kullanici_id`, `kullanici_resim`, `kullanici_isim`, `kullanici_mail`, `kullanici_sifre`) VALUES
(1, 'assets/img/28950257842237721580logo-test.jpg', 'Taha Script', 'info@tahascript.net', 'bcc9ad72fc3c1655d8fe7e2eb3c044bb');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `menuler`
--

CREATE TABLE `menuler` (
  `menu_id` int(11) NOT NULL,
  `menu_baslik` varchar(100) NOT NULL,
  `menu_link` varchar(250) NOT NULL,
  `menu_sira` int(2) NOT NULL,
  `menu_durum` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `menuler`
--

INSERT INTO `menuler` (`menu_id`, `menu_baslik`, `menu_link`, `menu_sira`, `menu_durum`) VALUES
(1, 'Ana Sayfa', '#home', 1, 1),
(2, 'Hakkımızda', '#about', 2, 1),
(3, 'Hizmetlerimiz', '#services', 3, 1),
(4, 'Takımımız', '#team', 4, 0),
(5, 'Portföy', '#portfolio', 5, 0),
(6, 'İletişim', '#contact', 6, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `portfoy`
--

CREATE TABLE `portfoy` (
  `portfoy_id` int(11) NOT NULL,
  `portfoy_resim` varchar(250) NOT NULL,
  `portfoy_baslik` varchar(100) NOT NULL,
  `portfoy_aciklama` varchar(100) NOT NULL,
  `portfoy_sira` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `portfoy`
--

INSERT INTO `portfoy` (`portfoy_id`, `portfoy_resim`, `portfoy_baslik`, `portfoy_aciklama`, `portfoy_sira`) VALUES
(1, 'img/portfolio/1.jpg', 'Resim Başlık', 'Resim Açıklama', 1),
(2, 'img/portfolio/2.jpg', 'Resim Başlık', 'Resim A&ccedil;ıklama', 2),
(3, 'img/portfolio/3.jpg', 'Resim Başlık', 'Resim Açıklama', 3),
(4, 'img/portfolio/4.jpg', 'Resim Başlık', 'Resim Açıklama', 4),
(5, 'img/portfolio/5.jpg', 'Resim Başlık', 'Resim Açıklama', 5),
(6, 'img/298712661123448305246.jpg', 'Resim Başlık', 'Resim Açıklama', 6);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(11) NOT NULL,
  `slider_h2` varchar(250) NOT NULL,
  `slider_h1` varchar(250) NOT NULL,
  `slider_resim` varchar(250) NOT NULL,
  `slider_buton_baslik` varchar(250) NOT NULL,
  `slider_buton_link` varchar(250) NOT NULL,
  `slider_sira` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_h2`, `slider_h1`, `slider_resim`, `slider_buton_baslik`, `slider_buton_link`, `slider_sira`) VALUES
(1, 'Güçlü Altyapı', 'R10.net Ailesine Özel Üretilmiş Bir Ücretsiz Script', 'img/slider1.jpg', 'DAHA FAZLASINI KEŞFET', '#about', 3),
(2, 'Responsive Tasarım', 'PHP Diliyle Kodlanmış Bootstrap Temalar İ&ccedil;ermektedir', 'img/22988298743176426598test.jpg', 'HİZMETLERİMİZ', '#services', 2),
(3, 'K&uuml;&ccedil;&uuml;k Başlıkk', 'Ana Başlık', 'img/24191241362816525736slider2.jpg', 'İNDİR', '#download', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `takimimiz`
--

CREATE TABLE `takimimiz` (
  `takimimiz_id` int(11) NOT NULL,
  `takimimiz_resim` varchar(250) NOT NULL,
  `takimimiz_adsoyad` varchar(150) NOT NULL,
  `takimimiz_rol` varchar(150) NOT NULL,
  `takimimiz_facebook` varchar(250) NOT NULL,
  `takimimiz_twitter` varchar(250) NOT NULL,
  `takimimiz_instagram` varchar(250) NOT NULL,
  `takimimiz_sira` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `takimimiz`
--

INSERT INTO `takimimiz` (`takimimiz_id`, `takimimiz_resim`, `takimimiz_adsoyad`, `takimimiz_rol`, `takimimiz_facebook`, `takimimiz_twitter`, `takimimiz_instagram`, `takimimiz_sira`) VALUES
(1, 'img/team/1.jpg', 'Ad Soyad', 'Seo Uzmanı', '#', '#', '#', 4),
(2, 'img/218182353929512215232.jpg', 'Ad Soyad', 'Web Geliştiricisi', '#', '#', '#', 3),
(3, 'img/team/3.jpg', 'Ad Soyad', 'Web Tasarımcısı', '#', '#', '#', 2),
(14, 'img/22446297022408027710285853184029834293644.jpg', 'Ad Soyad', 'Yönetici', '#', '#', '#', 1);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `afis`
--
ALTER TABLE `afis`
  ADD PRIMARY KEY (`afis_id`);

--
-- Tablo için indeksler `altbilgi`
--
ALTER TABLE `altbilgi`
  ADD PRIMARY KEY (`altbilgi_id`);

--
-- Tablo için indeksler `ayarlar`
--
ALTER TABLE `ayarlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `hakkimizda`
--
ALTER TABLE `hakkimizda`
  ADD PRIMARY KEY (`hakkimizda_id`);

--
-- Tablo için indeksler `hizmetlerimiz`
--
ALTER TABLE `hizmetlerimiz`
  ADD PRIMARY KEY (`hizmetlerimiz_id`);

--
-- Tablo için indeksler `ilaveler`
--
ALTER TABLE `ilaveler`
  ADD PRIMARY KEY (`ilaveler_id`);

--
-- Tablo için indeksler `iletisim`
--
ALTER TABLE `iletisim`
  ADD PRIMARY KEY (`iletisim_id`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`kullanici_id`);

--
-- Tablo için indeksler `menuler`
--
ALTER TABLE `menuler`
  ADD PRIMARY KEY (`menu_id`);

--
-- Tablo için indeksler `portfoy`
--
ALTER TABLE `portfoy`
  ADD PRIMARY KEY (`portfoy_id`);

--
-- Tablo için indeksler `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Tablo için indeksler `takimimiz`
--
ALTER TABLE `takimimiz`
  ADD PRIMARY KEY (`takimimiz_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `form`
--
ALTER TABLE `form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `hakkimizda`
--
ALTER TABLE `hakkimizda`
  MODIFY `hakkimizda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `hizmetlerimiz`
--
ALTER TABLE `hizmetlerimiz`
  MODIFY `hizmetlerimiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `kullanici_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `menuler`
--
ALTER TABLE `menuler`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `portfoy`
--
ALTER TABLE `portfoy`
  MODIFY `portfoy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Tablo için AUTO_INCREMENT değeri `takimimiz`
--
ALTER TABLE `takimimiz`
  MODIFY `takimimiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
