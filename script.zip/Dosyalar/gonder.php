<?php
/*

████████╗ █████╗ ██╗  ██╗ █████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗           ███╗   ██╗███████╗████████╗
╚══██╔══╝██╔══██╗██║  ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝           ████╗  ██║██╔════╝╚══██╔══╝
   ██║   ███████║███████║███████║███████╗██║     ██████╔╝██║██████╔╝   ██║              ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══██║██╔══██║██╔══██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║              ██║╚██╗██║██╔══╝     ██║   
   ██║   ██║  ██║██║  ██║██║  ██║███████║╚██████╗██║  ██║██║██║        ██║       ██╗    ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝       ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   

    Bu Yazılım, TahaScript.net Tarafından Yapılmıştır Ve Ücretsiz Olarak Yayınlanmıştır

    www.tahascript.net
*/

include 'yonetim/inc/dbconnect.php';


function securetext($x){
	$z = addslashes($x);
	$z = htmlspecialchars($z);
	$z = htmlentities($z);
	$z = strip_tags($z);
	return $z;
};



if (empty($_POST[''])) {
    header("Location: index.php");
}


  if (isset($_POST['form'])) {

    $gonder = $db->prepare("INSERT INTO form SET
      adsoyad = :adsoyad,
      eposta = :eposta,
      konu = :konu,
      mesaj = :mesaj");
    $insert = $gonder->execute(array(
      "adsoyad" => securetext($_POST['adsoyad']),
      "eposta" => securetext($_POST['eposta']),
      "konu" => securetext($_POST['konu']),
      "mesaj" => securetext($_POST['mesaj']),
    ));
    if ( $insert ){
        header("Location: index.php?status=success");
    } else {
        header("Location: index.php?status=error");
    }

  }


?>