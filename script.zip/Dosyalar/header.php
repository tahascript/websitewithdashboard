<?php
/*



████████╗ █████╗ ██╗  ██╗ █████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗           ███╗   ██╗███████╗████████╗
╚══██╔══╝██╔══██╗██║  ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝           ████╗  ██║██╔════╝╚══██╔══╝
   ██║   ███████║███████║███████║███████╗██║     ██████╔╝██║██████╔╝   ██║              ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══██║██╔══██║██╔══██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║              ██║╚██╗██║██╔══╝     ██║   
   ██║   ██║  ██║██║  ██║██║  ██║███████║╚██████╗██║  ██║██║██║        ██║       ██╗    ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝       ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   

    Bu Yazılım, TahaScript.net Tarafından Yapılmıştır Ve Ücretsiz Olarak Yayınlanmıştır

    www.tahascript.net


*/

include "yonetim/inc/dbconnect.php";
include "yonetim/functions.php"; ?>
<?php
$ayarlarsor=$db->prepare("SELECT * FROM ayarlar");
$ayarlarsor->execute(array(0));
$ayarlar=$ayarlarsor->fetch(PDO::FETCH_ASSOC);
?>
<?php copyright(); ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo $ayarlar['site_baslik']; ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="<?php echo $ayarlar['site_anahtar_kelimeler']; ?>" name="keywords">
  <meta content="<?php echo $ayarlar['site_aciklama']; ?>" name="description">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">

  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="assets/sweetalert2/sweetalert2.min.css">

  <!-- Nivo Slider Theme -->
  <link href="css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="css/responsive.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: eBusiness
    Theme URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="index.php">
                  
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <img src="<?php echo $ayarlar['site_logo'] ?>" style="height:36px;" alt="" title="">
								</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                <ul class="nav navbar-nav navbar-right">
        <?php
        $menurakam=1;
        $menusor=$db->prepare("SELECT * FROM menuler ORDER BY menu_sira ASC");
        $menusor->execute();
        while ($menu=$menusor->fetch(PDO::FETCH_ASSOC)) { $menurakam++; ?>
                  <li>
                    <a class="page-scroll" href="<?php echo $menu['menu_link']; ?>"><?php echo $menu['menu_baslik']; ?></a>
                  </li>
        <?php } ?>
                </ul>
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <!-- header end -->