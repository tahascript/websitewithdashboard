<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Ana Sayfa </h2>
                                <p class="pageheader-text"></p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Ana Sayfa</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">
                        <!-- WIDGET 1 AREA START -->
                        <div class="row">
                        <!-- ============================================================== -->
                        <!-- four widgets   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total views   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from takimimiz");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Kişi</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-info-light mt-1">
                                        <i class="fa fa-users fa-fw fa-sm text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total views   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total followers   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from portfoy");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Resim</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-primary-light mt-1">
                                        <i class="fa fa-image fa-fw fa-sm text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total followers   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- partnerships   -->
                        <!-- ============================================================== -->
                        
                        <!-- ============================================================== -->
                        <!-- end partnerships   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total earned   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from form");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Mesaj</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-brand-light mt-1">
                                        <i class="fa fa-inbox fa-fw fa-sm text-brand"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total earned   -->
                        <!-- ============================================================== -->
                    </div>
                        <!-- WIDGET 1 AREA END -->

                        


                        
                        <div class="row">
                            <!-- ============================================================== -->
                      
                            <!-- ============================================================== -->

                                          <!-- recent orders  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">Gelen Mesajlar</h5>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead class="bg-light">
                                                    <tr class="border-0">
                                                        <th class="border-0">id</th>
                                                        <th class="border-0">Ad Soyad</th>
                                                        <th class="border-0">E-posta</th>
                                                        <th class="border-0">Konu</th>
                                                        <th class="border-0">Mesaj</th>
                                                        <th width="80" class="border-0">İşlemler</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php

                                                $sayfada = 4;   // Sayfada Gösterilecek İçerik Miktarını Belirliyoruz.

                                                $sorgu=$db->prepare("SELECT * FROM form");
                                                $sorgu->execute();
                                                $toplam_form=$sorgu->rowCount();

                                                $toplam_sayfa = ceil($toplam_form / $sayfada);

                                                // Eğer Sayfa Girilmemişse 1 Sayalım

                                                $sayfa = isset($_GET['sayfa']) ? (int) $_GET['sayfa'] : 1;

                                                // Eğer 1'den küçük bir sayfa sayısı girildiye 1 yapalım
                                                if($sayfa < 1) $sayfa = 1;

                                                // Toplam sayfa sayımızdan fazla yapılırsa en son sayfayı varsayalım
                                                if ($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa;

                                                $limit = ($sayfa - 1) * $sayfada;




                                                $formsor=$db->prepare("SELECT * FROM form ORDER BY id ASC limit $limit, $sayfada");
                                                $formsor->execute();
                                                while ($form=$formsor->fetch(PDO::FETCH_ASSOC)) { ?>
                                                    <tr>
                                                        <td><?php echo $form['id'] ?></td>
                                                        <td><?php $adsoyad=$form['adsoyad']; if (strlen($adsoyad) > 25) { echo substr($adsoyad, 0, 25) . '...'; } else { echo $adsoyad; } ?></td>
                                                        <td><?php $eposta=$form['eposta']; if (strlen($eposta) > 25) { echo substr($eposta, 0, 25) . '...'; } else { echo $eposta; } ?></td>
                                                        <td><?php $konu=$form['konu']; if (strlen($konu) > 25) { echo substr($konu, 0, 25) . '...'; } else { echo $konu; } ?></td>
                                                        <td><?php $mesaj=$form['mesaj']; if (strlen($mesaj) > 25) { echo substr($mesaj, 0, 25) . '...'; } else { echo $mesaj; } ?></td>

                                                        <td>
                                                            <div class="d-flex">
                                                                <form class="mx-1" action="inc/process.php" method="POST">
                                                                    <input type="hidden" name="id" value="<?php echo $form['id'] ?>">
                                                                    <button type="submit" name="mesajsil" class="btn btn-danger btn-sm btn-icon-split">
                                                                    <span class="icon text-white-60">
                                                                        <i class="fas fa-trash"></i>
                                                                    </span>
                                                                    </button>
                                                                </form>
                                                                <form action="mesaj-goruntule.php" method="POST">
                                                                    <input type="hidden" name="id" value="<?php echo $form['id'] ?>">
                                                                    <button type="submit" name="mesajgoruntule" class="btn btn-primary btn-sm btn-icon-split">
                                                                    <span class="icon text-white-60">
                                                                        <i class="fas fa-eye"></i>
                                                                    </span>
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php } ?>
                                                    
                                                    
                                                    
                                                    
                                                </tbody>
                                            </table>
                                                    <div align="right" class="col md-12">
                                                    <ul class="pagination">

                                                    <?php

                                                    $s=0;

                                                    while ($s < $toplam_sayfa) { $s++ ?>

                                                    <?php if ($s==$sayfa) { ?>

                                                    <li class="page-item active"><a class="page-link" href="gelen-kutusu.php?sayfa=<?php echo $s; ?>"><?php echo $s; ?></a></li>
                                                    
                                                    <?php } else { ?>

                                                    <li class="page-item"><a class="page-link" href="gelen-kutusu.php?sayfa=<?php echo $s; ?>"><?php echo $s; ?></a></li>

                                                    <?php } } ?>
                                                
                                                    
                                                    </ul>
                                                    </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end recent orders  -->

    
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- customer acquistion  -->
                            <!-- ============================================================== -->
                            
                            <!-- ============================================================== -->
                            <!-- end customer acquistion  -->
                            <!-- ============================================================== -->
                        </div>

                                                <!-- WIDGET AREA START -->
                                                <div class="row">
                        <!-- ============================================================== -->
                        <!-- four widgets   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total views   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from menuler");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Menü</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-info-light mt-1">
                                        <i class="fa fa-bars fa-fw fa-sm text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total views   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total followers   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from slider");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Slider</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-primary-light mt-1">
                                        <i class="fa fa-images fa-fw fa-sm text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total followers   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- partnerships   -->
                        <!-- ============================================================== -->
                        
                        <!-- ============================================================== -->
                        <!-- end partnerships   -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total earned   -->
                        <!-- ============================================================== -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-inline-block">
<?php
$count=$db->prepare("select * from hizmetlerimiz");
$count->execute();
$no=$count->rowCount();
?>
                                        <h5 class="text-muted">Toplam Hizmet</h5>
                                        <h2 class="mb-0"> <?php echo $no; ?></h2>
                                    </div>
                                    <div class="float-right icon-circle-medium  icon-box-lg  bg-brand-light mt-1">
                                        <i class="fa fa-clipboard-list fa-fw fa-sm text-brand"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total earned   -->
                        <!-- ============================================================== -->
                    </div>
                        <!-- WIDGET AREA END -->
                        

                        
                        
                        
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>