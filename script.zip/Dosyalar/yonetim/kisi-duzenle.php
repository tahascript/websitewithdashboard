<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>

<?php
if (isset($_POST['takimimiz_id'])) {
	$kisiquery=$db->prepare("SELECT * FROM takimimiz where takimimiz_id=:id");
	$kisiquery->execute(array(
		'id' => $_POST['takimimiz_id']
	));
	$kisiler=$kisiquery->fetch(PDO::FETCH_ASSOC);
} else {
	header("Location: kisiler.php");
} 
?>

<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Kişi Düzenle </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Takımımız</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Kişi Düzenle</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Kişi Düzenle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" class="form-control" name="takimimiz_resim" value="<?php echo $kisiler['takimimiz_resim'] ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Seçili Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <div class="m-r-10"><img src="<?php echo '../'.$kisiler['takimimiz_resim'] ?>" class="rounded" width="100"></div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" name="takimimiz_resim" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Ad Soyad</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_adsoyad" value="<?php echo $kisiler['takimimiz_adsoyad'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Rolü</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_rol" value="<?php echo $kisiler['takimimiz_rol'] ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Sıra</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_sira" value="<?php echo $kisiler['takimimiz_sira'] ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Facebook</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_facebook" value="<?php echo $kisiler['takimimiz_facebook'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Twitter</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_twitter" value="<?php echo $kisiler['takimimiz_twitter'] ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İnstagram</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_instagram" value="<?php echo $kisiler['takimimiz_instagram'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <input type="hidden" class="form-control" name="takimimiz_id" value="<?php echo $_POST['takimimiz_id'] ?>">
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="kisiduzenle" type="submit" class="btn btn-space btn-primary">Kaydet</button>
                                            </div>
                                        </div>
</form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>