<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>

<?php
$hakkimizdaquery=$db->prepare("SELECT * FROM hakkimizda");
$hakkimizdaquery->execute(array(0));
$hakkimizda=$hakkimizdaquery->fetch(PDO::FETCH_ASSOC);
?>

<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Hakkımızda İçerik </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Hakkımızda</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Hakkımızda İçerik</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Hakkımızda Düzenle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" class="form-control" name="hakkimizda_resim" value="<?php echo $hakkimizda['hakkimizda_resim'] ?>">
                                    <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Seçili Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <div class="m-r-10"><img src="<?php echo '../'.$hakkimizda['hakkimizda_resim'] ?>" class="rounded" width="100"></div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Hakkımızda Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" name="hakkimizda_resim" class="form-control">
                                            </div>
                                        </div>
                                        <input type="hidden" class="form-control" name="slider_resim" value="<?php echo $_POST['hakkimizda_resim'] ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Hakkımızda Başlık</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="hakkimizda_baslik" value="<?php echo $hakkimizda['hakkimizda_baslik'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Hakkımızda İçerik</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <textarea class="ckeditor" id="editor1" name="hakkimizda_icerik"><?php echo $hakkimizda['hakkimizda_icerik'] ?></textarea>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="hakkimizda" type="submit" class="btn btn-space btn-primary">Kaydet</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>