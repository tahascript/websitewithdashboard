<?php
/*

████████╗ █████╗ ██╗  ██╗ █████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗           ███╗   ██╗███████╗████████╗
╚══██╔══╝██╔══██╗██║  ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝           ████╗  ██║██╔════╝╚══██╔══╝
   ██║   ███████║███████║███████║███████╗██║     ██████╔╝██║██████╔╝   ██║              ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══██║██╔══██║██╔══██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║              ██║╚██╗██║██╔══╝     ██║   
   ██║   ██║  ██║██║  ██║██║  ██║███████║╚██████╗██║  ██║██║██║        ██║       ██╗    ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝       ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   

    Bu Yazılım, TahaScript.net Tarafından Yapılmıştır Ve Ücretsiz Olarak Yayınlanmıştır

    www.tahascript.net
*/

ob_start();
session_start();


include 'dbconnect.php';
include '../functions.php';

if (empty($_POST[''])) {
  header("Location: ../index.php");
}



function securetext($x){
	$z = addslashes($x);
	$z = htmlspecialchars($z);
	$z = htmlentities($z);
	$z = strip_tags($z);
	return $z;
};

function securecontent($x){
	$z = addslashes($x);
	//$z = htmlspecialchars($z);
	//$z = htmlentities($z);
	//$z = strip_tags($z);
	return $z;
};




if (isset($_POST['login'])) {
  $kullanici_mail = $_POST['kullanici_mail'];
  $kullanici_sifre = md5($_POST['kullanici_sifre']);


  if ($kullanici_mail && $kullanici_sifre) {
      $kullanicisor=$db->prepare("SELECT * FROM kullanicilar WHERE kullanici_mail = :mail AND kullanici_sifre = :sifre");
      $kullanicisor->execute(array(
        'mail' => $kullanici_mail,
        'sifre' => $kullanici_sifre
      ));

      $say=$kullanicisor->rowCount();


      if ($say > 0) {
        $_SESSION['kullanici_mail'] = $kullanici_mail;
        header("Location: ../index.php?status=success");
      } else {
        header("Location: ../giris.php?status=error");
      }
  }
}













  if (isset($_POST['menuekle'])) {

    $menuquery = $db->prepare("INSERT INTO menuler SET
      menu_baslik = :menu_baslik,
      menu_link = :menu_link,
      menu_sira = :menu_sira");
    $insert = $menuquery->execute(array(
      "menu_baslik" => securetext($_POST['menu_baslik']),
      "menu_link" => securetext($_POST['menu_link']),
      "menu_sira" => securetext($_POST['menu_sira']),
    ));
    if ( $insert ){
        header("Location: ../menuler.php?status=success");
    } else {
        header("Location: ../menuler.php?status=error");
    }

  }


  if (isset($_POST['menuduzenle'])) {

    $menuquery = $db->prepare("UPDATE menuler SET
      menu_baslik = :menu_baslik,
      menu_link = :menu_link,
      menu_sira = :menu_sira
      WHERE menu_id={$_POST['menu_id']}");
    $insert = $menuquery->execute(array(
      "menu_baslik" => securetext($_POST['menu_baslik']),
      "menu_link" => securetext($_POST['menu_link']),
      "menu_sira" => securetext($_POST['menu_sira'])
    ));
    if ( $insert ){
        header("Location: ../menuler.php?status=success");
    } else {
        header("Location: ../menuler.php?status=error");
    }

  }


if (isset($_POST['menusil'])) {
  $menuquery = $db->prepare("DELETE FROM menuler WHERE menu_id = :id");
  $delete = $menuquery->execute(array(
     'id' => securetext($_POST['menu_id'])
  ));

  if ($delete) {
    header("Location: ../menuler.php?status=success");
  } else {
    header("Location: ../menuler.php?status=error");
  }

}






if (isset($_POST['sliderekle'])) {

   $uploads_dir = '../../img';
   @$tmp_name = $_FILES['slider_resim']["tmp_name"];
   $name = $_FILES['slider_resim']["name"];
   $benzersizsayi1=rand(20000,32000);
   $benzersizsayi2=rand(20000,32000);
   $benzersizsayi3=rand(20000,32000);
   $benzersizsayi4=rand(20000,32000);
   $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
   $imgyol=substr($uploads_dir, 6)."/".$benzersizad.$name;
   @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");


  $sliderquery = $db->prepare("INSERT INTO slider SET
    slider_h2 = :slider_h2,
    slider_h1 = :slider_h1,
    slider_buton_baslik = :slider_buton_baslik,
    slider_buton_link = :slider_buton_link,
    slider_sira = :slider_sira
    slider_resim = :slider_resim");
  $insert = $sliderquery->execute(array(
    "slider_h2" => securetext($_POST['slider_h2']),
    "slider_h1" => securetext($_POST['slider_h1']),
    "slider_buton_baslik" => securetext($_POST['slider_buton_baslik']),
    "slider_buton_link" => securetext($_POST['slider_buton_link']),
    "slider_sira" => securetext($_POST['slider_sira']),
    "slider_resim" => $imgyol
  ));
  if ( $insert ){
      header("Location: ../sliderlar.php?status=success");
  } else {
      header("Location: ../sliderlar.php?status=error");
  }


}



if (isset($_POST['sliderduzenle'])) {

  if ($_FILES['slider_resim']["size"] > 0) {

    $uploads_dir = '../../img';
    @$tmp_name = $_FILES['slider_resim']["tmp_name"];
    $name = $_FILES['slider_resim']["name"];
    $benzersizsayi1=rand(20000,32000);
    $benzersizsayi2=rand(20000,32000);
    $benzersizsayi3=rand(20000,32000);
    $benzersizsayi4=rand(20000,32000);
    $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
    $imgyol=substr($uploads_dir, 6)."/".$benzersizad.$name;
    @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

    $sliderquery = $db->prepare("UPDATE slider SET
    slider_resim = :slider_resim
    WHERE slider_id={$_POST['slider_id']}");
  $insert = $sliderquery->execute(array(
    "slider_resim" => $imgyol
  ));

    $sliderquery = $db->prepare("UPDATE slider SET
    slider_h2 = :slider_h2,
    slider_h1 = :slider_h1,
    slider_buton_baslik = :slider_buton_baslik,
    slider_buton_link = :slider_buton_link,
    slider_sira = :slider_sira
    WHERE slider_id={$_POST['slider_id']}");
  $insert = $sliderquery->execute(array(
    "slider_h2" => securetext($_POST['slider_h2']),
    "slider_h1" => securetext($_POST['slider_h1']),
    "slider_buton_baslik" => securetext($_POST['slider_buton_baslik']),
    "slider_buton_link" => securetext($_POST['slider_buton_link']),
    "slider_sira" => securetext($_POST['slider_sira']),
  ));
  
  if ( $insert ){
    $resimsil=$_POST['slider_resim'];
    unlink("../../$resimsil");

      header("Location: ../sliderlar.php?status=success");
  } else {
      header("Location: ../sliderlar.php?status=error");
  }

    
/* Eğer Resimde Değişiklik Yoksa Sadece Yazılar Güncellensin Diye Burası Var (Alt Taraf) */
  } else {
    $sliderquery = $db->prepare("UPDATE slider SET
    slider_h2 = :slider_h2,
    slider_h1 = :slider_h1,
    slider_buton_baslik = :slider_buton_baslik,
    slider_buton_link = :slider_buton_link,
    slider_sira = :slider_sira
    WHERE slider_id={$_POST['slider_id']}");
  $insert = $sliderquery->execute(array(
    "slider_h2" => securetext($_POST['slider_h2']),
    "slider_h1" => securetext($_POST['slider_h1']),
    "slider_buton_baslik" => securetext($_POST['slider_buton_baslik']),
    "slider_buton_link" => securetext($_POST['slider_buton_link']),
    "slider_sira" => securetext($_POST['slider_sira']),
  ));
  if ( $insert ){
      header("Location: ../sliderlar.php?status=success");
  } else {
      header("Location: ../sliderlar.php?status=error");
  }
  
}

}



if (isset($_POST['slidersil'])) {
  $sliderquery = $db->prepare("DELETE FROM slider WHERE slider_id = :id");
  $delete = $sliderquery->execute(array(
     'id' => securetext($_POST['slider_id'])
  ));

  if ($delete) {
    header("Location: ../sliderlar.php?status=success");
  } else {
    header("Location: ../sliderlar.php?status=error");
  }

}












if (isset($_POST['hakkimizda'])) {

  if ($_FILES['hakkimizda_resim']["size"] > 0) {

    $uploads_dir = '../../img';
    @$tmp_name = $_FILES['hakkimizda_resim']["tmp_name"];
    $name = $_FILES['hakkimizda_resim']["name"];
    $benzersizsayi1=rand(20000,32000);
    $benzersizsayi2=rand(20000,32000);
    $benzersizsayi3=rand(20000,32000);
    $benzersizsayi4=rand(20000,32000);
    $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
    $imgyol=substr($uploads_dir, 6)."/".$benzersizad.$name;
    @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

    $hakkimizdaquery = $db->prepare("UPDATE hakkimizda SET
    hakkimizda_baslik = :hakkimizda_baslik,
    hakkimizda_icerik = :hakkimizda_icerik,
    hakkimizda_resim = :hakkimizda_resim
    WHERE hakkimizda_id=1");
  $insert = $hakkimizdaquery->execute(array(
    "hakkimizda_baslik" => securetext($_POST['hakkimizda_baslik']),
    "hakkimizda_icerik" => securecontent($_POST['hakkimizda_icerik']),
    "hakkimizda_resim" => $imgyol
  ));

    if ( $insert ){
      $resimsil=$_POST['hakkimizda_resim'];
      unlink("../../$resimsil");
      
      header("Location: ../hakkimizda.php?status=success");
  } else {
      header("Location: ../hakkimizda.php?status=error");
  }


  } else {

  $hakkimizdaquery = $db->prepare("UPDATE hakkimizda SET
    hakkimizda_baslik = :hakkimizda_baslik,
    hakkimizda_icerik = :hakkimizda_icerik
    WHERE hakkimizda_id=1");
  $insert = $hakkimizdaquery->execute(array(
    "hakkimizda_baslik" => securetext($_POST['hakkimizda_baslik']),
    "hakkimizda_icerik" => securecontent($_POST['hakkimizda_icerik']),
  ));
  if ( $insert ){
      header("Location: ../hakkimizda.php?status=success");
  } else {
      header("Location: ../hakkimizda.php?status=error");
  }

  }


}














if (isset($_POST['hizmetekle'])) {

  $hizmetlerquery = $db->prepare("INSERT INTO hizmetlerimiz SET
    hizmetlerimiz_icon = :hizmetlerimiz_icon,
    hizmetlerimiz_baslik = :hizmetlerimiz_baslik,
    hizmetlerimiz_icerik = :hizmetlerimiz_icerik,
    hizmetlerimiz_sira = :hizmetlerimiz_sira");
  $insert = $hizmetlerquery->execute(array(
    "hizmetlerimiz_icon" => securetext($_POST['hizmetlerimiz_icon']),
    "hizmetlerimiz_baslik" => securetext($_POST['hizmetlerimiz_baslik']),
    "hizmetlerimiz_icerik" => securecontent($_POST['hizmetlerimiz_icerik']),
    "hizmetlerimiz_sira" => securetext($_POST['hizmetlerimiz_sira']),
  ));
  if ( $insert ){
      header("Location: ../hizmetler.php?status=success");
  } else {
      header("Location: ../hizmetler.php?status=error");
  }

}


if (isset($_POST['hizmetduzenle'])) {

  $hizmetlerquery = $db->prepare("UPDATE hizmetlerimiz SET
    hizmetlerimiz_icon = :hizmetlerimiz_icon,
    hizmetlerimiz_baslik = :hizmetlerimiz_baslik,
    hizmetlerimiz_icerik = :hizmetlerimiz_icerik,
    hizmetlerimiz_sira = :hizmetlerimiz_sira
    WHERE hizmetlerimiz_id={$_POST['hizmetlerimiz_id']}");
  $insert = $hizmetlerquery->execute(array(
    "hizmetlerimiz_icon" => securetext($_POST['hizmetlerimiz_icon']),
    "hizmetlerimiz_baslik" => securetext($_POST['hizmetlerimiz_baslik']),
    "hizmetlerimiz_icerik" => securecontent($_POST['hizmetlerimiz_icerik']),
    "hizmetlerimiz_sira" => securetext($_POST['hizmetlerimiz_sira'])
  ));
  if ( $insert ){
      header("Location: ../hizmetler.php?status=success");
  } else {
      header("Location: ../hizmetler.php?status=error");
  }

}


if (isset($_POST['hizmetsil'])) {
$hizmetlerquery = $db->prepare("DELETE FROM hizmetlerimiz WHERE hizmetlerimiz_id = :id");
$delete = $hizmetlerquery->execute(array(
   'id' => securetext($_POST['hizmetlerimiz_id'])
));

if ($delete) {
  header("Location: ../hizmetler.php?status=success");
} else {
  header("Location: ../hizmetler.php?status=error");
}

}





















if (isset($_POST['kisiekle'])) {

  $uploads_dir = '../../img';
  @$tmp_name = $_FILES['takimimiz_resim']["tmp_name"];
  $name = $_FILES['takimimiz_resim']["name"];
  $benzersizsayi1=rand(20000,32000);
  $benzersizsayi2=rand(20000,32000);
  $benzersizsayi3=rand(20000,32000);
  $benzersizsayi4=rand(20000,32000);
  $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
  $imgyol2=substr($uploads_dir, 6)."/".$benzersizad.$name;
  @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");


 $kisiquery = $db->prepare("INSERT INTO takimimiz SET
   takimimiz_adsoyad = :takimimiz_adsoyad,
   takimimiz_rol = :takimimiz_rol,
   takimimiz_facebook = :takimimiz_facebook,
   takimimiz_twitter = :takimimiz_twitter,
   takimimiz_instagram = :takimimiz_instagram,
   takimimiz_sira = :takimimiz_sira,
   takimimiz_resim = :takimimiz_resim
   ");
 $insert = $kisiquery->execute(array(
   "takimimiz_adsoyad" => securetext($_POST['takimimiz_adsoyad']),
   "takimimiz_rol" => securetext($_POST['takimimiz_rol']),
   "takimimiz_facebook" => securetext($_POST['takimimiz_facebook']),
   "takimimiz_twitter" => securetext($_POST['takimimiz_twitter']),
   "takimimiz_instagram" => securetext($_POST['takimimiz_instagram']),
   "takimimiz_sira" => securetext($_POST['takimimiz_sira']),
   "takimimiz_resim" => $imgyol2
 ));
 if ( $insert ){
     header("Location: ../kisiler.php?status=success");
 } else {
     header("Location: ../kisiler.php?status=error");
 }


}



























/* */ /* */

if (isset($_POST['kisiduzenle'])) {

 if ($_FILES['takimimiz_resim']["size"] > 0) {

   $uploads_dir = '../../img';
   @$tmp_name = $_FILES['takimimiz_resim']["tmp_name"];
   $name = $_FILES['takimimiz_resim']["name"];
   $benzersizsayi1=rand(20000,32000);
   $benzersizsayi2=rand(20000,32000);
   $benzersizsayi3=rand(20000,32000);
   $benzersizsayi4=rand(20000,32000);
   $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
   $imgyol2=substr($uploads_dir, 6)."/".$benzersizad.$name;
   @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

   $takimimizquery = $db->prepare("UPDATE takimimiz SET
   takimimiz_resim = :takimimiz_resim
   WHERE takimimiz_id={$_POST['takimimiz_id']}");
 $insert = $takimimizquery->execute(array(
   "takimimiz_resim" => $imgyol2
 ));

   $takimimizquery = $db->prepare("UPDATE takimimiz SET
   takimimiz_adsoyad = :takimimiz_adsoyad,
   takimimiz_rol = :takimimiz_rol,
   takimimiz_facebook = :takimimiz_facebook,
   takimimiz_twitter = :takimimiz_twitter,
   takimimiz_instagram = :takimimiz_instagram,
   takimimiz_sira = :takimimiz_sira
   WHERE takimimiz_id={$_POST['takimimiz_id']}");
 $insert = $takimimizquery->execute(array(
   "takimimiz_adsoyad" => securetext($_POST['takimimiz_adsoyad']),
   "takimimiz_rol" => securetext($_POST['takimimiz_rol']),
   "takimimiz_facebook" => securetext($_POST['takimimiz_facebook']),
   "takimimiz_twitter" => securetext($_POST['takimimiz_twitter']),
   "takimimiz_instagram" => securetext($_POST['takimimiz_instagram']),
   "takimimiz_sira" => securetext($_POST['takimimiz_sira'])
 ));
 
 if ( $insert ){
     $resimsil=$_POST['takimimiz_resim'];
      unlink("../../$resimsil");

     header("Location: ../kisiler.php?status=success");
 } else {
     header("Location: ../kisiler.php?status=error");
 }

   
/* Eğer Resimde Değişiklik Yoksa Sadece Yazılar Güncellensin Diye Burası Var (Alt Taraf) */
 } else {
   $takimimizquery = $db->prepare("UPDATE takimimiz SET
   takimimiz_adsoyad = :takimimiz_adsoyad,
   takimimiz_rol = :takimimiz_rol,
   takimimiz_facebook = :takimimiz_facebook,
   takimimiz_twitter = :takimimiz_twitter,
   takimimiz_instagram = :takimimiz_instagram,
   takimimiz_sira = :takimimiz_sira
   WHERE takimimiz_id={$_POST['takimimiz_id']}");
 $insert = $takimimizquery->execute(array(
  "takimimiz_adsoyad" => securetext($_POST['takimimiz_adsoyad']),
  "takimimiz_rol" => securetext($_POST['takimimiz_rol']),
  "takimimiz_facebook" => securetext($_POST['takimimiz_facebook']),
  "takimimiz_twitter" => securetext($_POST['takimimiz_twitter']),
  "takimimiz_instagram" => securetext($_POST['takimimiz_instagram']),
  "takimimiz_sira" =>securetext( $_POST['takimimiz_sira'])
 ));
 if ( $insert ){
     header("Location: ../kisiler.php?status=success");
 } else {
     header("Location: ../kisiler.php?status=error");
 }
 
}

}


















if (isset($_POST['kisisil'])) {
 $takimimizquery = $db->prepare("DELETE FROM takimimiz WHERE takimimiz_id = :id");
 $delete = $takimimizquery->execute(array(
    'id' => securetext($_POST['takimimiz_id'])
 ));

 if ($delete) {
   header("Location: ../kisiler.php?status=success");
 } else {
   header("Location: ../kisiler.php?status=error");
 }

}






/* ********************************************************************************************************************* */

/* ********************************************************************************************************************* */




if (isset($_POST['resimekle'])) {

  $uploads_dir = '../../img';
  @$tmp_name = $_FILES['portfoy_resim']["tmp_name"];
  $name = $_FILES['portfoy_resim']["name"];
  $benzersizsayi1=rand(20000,32000);
  $benzersizsayi2=rand(20000,32000);
  $benzersizsayi3=rand(20000,32000);
  $benzersizsayi4=rand(20000,32000);
  $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
  $imgyol4=substr($uploads_dir, 6)."/".$benzersizad.$name;
  @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");


 $resimquery = $db->prepare("INSERT INTO portfoy SET
   portfoy_baslik = :portfoy_baslik,
   portfoy_aciklama = :portfoy_aciklama,
   portfoy_sira = :portfoy_sira,
   portfoy_resim = :portfoy_resim
   ");
 $insert = $resimquery->execute(array(
   "portfoy_baslik" => securetext($_POST['portfoy_baslik']),
   "portfoy_aciklama" => securetext($_POST['portfoy_aciklama']),
   "portfoy_sira" => securetext($_POST['portfoy_sira']),
   "portfoy_resim" => $imgyol4
 ));
 if ( $insert ){
     header("Location: ../resimler.php?status=success");
 } else {
     header("Location: ../resimler.php?status=error");
 }


}



























/* */ /* */

if (isset($_POST['resimduzenle'])) {

 if ($_FILES['portfoy_resim']["size"] > 0) {

   $uploads_dir = '../../img';
   @$tmp_name = $_FILES['portfoy_resim']["tmp_name"];
   $name = $_FILES['portfoy_resim']["name"];
   $benzersizsayi1=rand(20000,32000);
   $benzersizsayi2=rand(20000,32000);
   $benzersizsayi3=rand(20000,32000);
   $benzersizsayi4=rand(20000,32000);
   $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
   $imgyol4=substr($uploads_dir, 6)."/".$benzersizad.$name;
   @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

   $resimquery = $db->prepare("UPDATE portfoy SET
   portfoy_resim = :portfoy_resim
   WHERE portfoy_id={$_POST['portfoy_id']}");
 $insert = $resimquery->execute(array(
   "portfoy_resim" => $imgyol4
 ));

   $resimquery = $db->prepare("UPDATE portfoy SET
   portfoy_baslik = :portfoy_baslik,
   portfoy_aciklama = :portfoy_aciklama,
   portfoy_sira = :portfoy_sira
   WHERE takimimiz_id={$_POST['takimimiz_id']}");
 $insert = $resimquery->execute(array(
   "portfoy_baslik" => securetext($_POST['portfoy_baslik']),
   "portfoy_aciklama" => securetext($_POST['portfoy_aciklama']),
   "portfoy_sira" => securetext($_POST['portfoy_sira'])
 ));
 
 if ( $insert ){
     $resimsil=$_POST['portfoy_resim'];
      unlink("../../$resimsil");

     header("Location: ../resimler.php?status=success");
 } else {
     header("Location: ../resimler.php?status=error");
 }

   
/* Eğer Resimde Değişiklik Yoksa Sadece Yazılar Güncellensin Diye Burası Var (Alt Taraf) */
 } else {
   $resimquery = $db->prepare("UPDATE portfoy SET
   portfoy_baslik = :portfoy_baslik,
   portfoy_aciklama = :portfoy_aciklama,
   portfoy_sira = :portfoy_sira
   WHERE portfoy_id={$_POST['portfoy_id']}");
 $insert = $resimquery->execute(array(
   "portfoy_baslik" => securetext($_POST['portfoy_baslik']),
   "portfoy_aciklama" => securetext($_POST['portfoy_aciklama']),
   "portfoy_sira" => securetext($_POST['portfoy_sira'])
 ));
 if ( $insert ){
     header("Location: ../resimler.php?status=success");
 } else {
     header("Location: ../resimler.php?status=error");
 }
 
}

}


















if (isset($_POST['resimsil'])) {
 $resimquery = $db->prepare("DELETE FROM portfoy WHERE portfoy_id = :id");
 $delete = $resimquery->execute(array(
    'id' => securetext($_POST['portfoy_id'])
 ));

 if ($delete) {
   header("Location: ../resimler.php?status=success");
 } else {
   header("Location: ../resimler.php?status=error");
 }

}


/* **************************************************************************************************** */

if (isset($_POST['altbilgi'])) {

  if ($_FILES['altbilgi_resim']["size"] > 0) {

    $uploads_dir = '../../img';
    @$tmp_name = $_FILES['altbilgi_resim']["tmp_name"];
    $name = $_FILES['altbilgi_resim']["name"];
    $benzersizsayi1=rand(20000,32000);
    $benzersizsayi2=rand(20000,32000);
    $benzersizsayi3=rand(20000,32000);
    $benzersizsayi4=rand(20000,32000);
    $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
    $imgyol5=substr($uploads_dir, 6)."/".$benzersizad.$name;
    @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

    $altbilgiquery = $db->prepare("UPDATE altbilgi SET
    altbilgi_icerik = :altbilgi_icerik,
    altbilgi_vizyon = :altbilgi_vizyon,
    altbilgi_misyon = :altbilgi_misyon,
    altbilgi_facebook = :altbilgi_facebook,
    altbilgi_twitter = :altbilgi_twitter,
    altbilgi_instagram = :altbilgi_instagram,
    altbilgi_resim = :altbilgi_resim
    WHERE altbilgi_id=1");
  $insert = $altbilgiquery->execute(array(
    "altbilgi_icerik" => securecontent($_POST['altbilgi_icerik']),
    "altbilgi_vizyon" => securecontent($_POST['altbilgi_vizyon']),
    "altbilgi_misyon" => securecontent($_POST['altbilgi_misyon']),
    "altbilgi_facebook" => securetext($_POST['altbilgi_facebook']),
    "altbilgi_twitter" => securetext($_POST['altbilgi_twitter']),
    "altbilgi_instagram" => securetext($_POST['altbilgi_instagram']),
    "altbilgi_resim" => $imgyol5
  ));

    if ( $insert ){
      $resimsil=$_POST['hakkimizda_resim'];
      unlink("../../$resimsil");

      header("Location: ../altbilgi.php?status=success");
  } else {
      header("Location: ../altbilgi.php?status=error");
  }


  } else {

  $altbilgiquery = $db->prepare("UPDATE altbilgi SET
    altbilgi_icerik = :altbilgi_icerik,
    altbilgi_vizyon = :altbilgi_vizyon,
    altbilgi_misyon = :altbilgi_misyon,
    altbilgi_facebook = :altbilgi_facebook,
    altbilgi_twitter = :altbilgi_twitter,
    altbilgi_instagram = :altbilgi_instagram
    WHERE altbilgi_id=1");
  $insert = $altbilgiquery->execute(array(
    "altbilgi_icerik" => securecontent($_POST['altbilgi_icerik']),
    "altbilgi_vizyon" => securecontent($_POST['altbilgi_vizyon']),
    "altbilgi_misyon" => securecontent($_POST['altbilgi_misyon']),
    "altbilgi_facebook" => securetext($_POST['altbilgi_facebook']),
    "altbilgi_twitter" => securetext($_POST['altbilgi_twitter']),
    "altbilgi_instagram" => securetext($_POST['altbilgi_instagram']),
  ));
  if ( $insert ){
      header("Location: ../altbilgi.php?status=success");
  } else {
      header("Location: ../altbilgi.php?status=error");
  }

  }


}




/* ******************************************************************************************************************************** */



if (isset($_POST['ayarlar'])) {

  if ($_FILES['site_logo']["size"] > 0) {

    $uploads_dir = '../../img';
    @$tmp_name = $_FILES['site_logo']["tmp_name"];
    $name = $_FILES['site_logo']["name"];
    $benzersizsayi1=rand(20000,32000);
    $benzersizsayi2=rand(20000,32000);
    $benzersizsayi3=rand(20000,32000);
    $benzersizsayi4=rand(20000,32000);
    $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
    $imgyol7=substr($uploads_dir, 6)."/".$benzersizad.$name;
    @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");

    $ayarlarquery = $db->prepare("UPDATE ayarlar SET
    site_baslik = :site_baslik,
    site_aciklama = :site_aciklama,
    site_anahtar_kelimeler = :site_anahtar_kelimeler,
    site_sahip = :site_sahip,
    site_logo = :site_logo
    WHERE id=1");
  $insert = $ayarlarquery->execute(array(
    "site_baslik" => securetext($_POST['site_baslik']),
    "site_aciklama" => securetext($_POST['site_aciklama']),
    "site_anahtar_kelimeler" => securetext($_POST['site_anahtar_kelimeler']),
    "site_sahip" => securetext($_POST['site_sahip']),
    "site_logo" => $imgyol7
  ));

    if ( $insert ){

      $resimsil=$_POST['site_logo'];
      unlink("../../$resimsil");

      header("Location: ../ayarlar.php?status=success");
  } else {
      header("Location: ../ayarlar.php?status=error");
  }


  } else {

  $ayarlarquery = $db->prepare("UPDATE ayarlar SET
    site_baslik = :site_baslik,
    site_aciklama = :site_aciklama,
    site_anahtar_kelimeler = :site_anahtar_kelimeler,
    site_sahip = :site_sahip
    WHERE id=1");
  $insert = $ayarlarquery->execute(array(
    "site_baslik" => securetext($_POST['site_baslik']),
    "site_aciklama" => securetext($_POST['site_aciklama']),
    "site_anahtar_kelimeler" => securetext($_POST['site_anahtar_kelimeler']),
    "site_sahip" => securetext($_POST['site_sahip'])
  ));
  if ( $insert ){
      header("Location: ../ayarlar.php?status=success");
  } else {
      header("Location: ../ayarlar.php?status=error");
  }

  }


}


/* ********************************************************************************************* */













if (isset($_POST['iletisim'])) {

  $iletisimquery = $db->prepare("UPDATE iletisim SET
    iletisim_baslik = :iletisim_baslik,
    iletisim_harita = :iletisim_harita,
    iletisim_telefon = :iletisim_telefon,
    iletisim_mail = :iletisim_mail,
    iletisim_adres = :iletisim_adres
    WHERE iletisim_id=1");
  $insert = $iletisimquery->execute(array(
    "iletisim_baslik" => securetext($_POST['iletisim_baslik']),
    "iletisim_harita" => securetext($_POST['iletisim_harita']),
    "iletisim_telefon" => securecontent($_POST['iletisim_telefon']),
    "iletisim_mail" => securecontent($_POST['iletisim_mail']),
    "iletisim_adres" => securecontent($_POST['iletisim_adres'])
  ));
  if ( $insert ){
      header("Location: ../iletisim.php?status=success");
  } else {
      header("Location: ../iletisim.php?status=error");
  }

}



/* *************************************************************************************************************** */


if (isset($_POST['mesajsil'])) {
  $formquery = $db->prepare("DELETE FROM form WHERE id = :id");
  $delete = $formquery->execute(array(
     'id' => securetext($_POST['id'])
  ));

  if ($delete) {
    header("Location: ../gelen-kutusu.php?status=success");
  } else {
    header("Location: ../gelen-kutusu.php?status=error");
  }

}




/* ************************************************************************************************************** */



if (isset($_POST['sifre'])) {

  $oldpass=securetext($_POST['oldpass']);
  $newpass1=securetext($_POST['newpass1']); 
  $newpass2=securetext($_POST['newpass2']);

  $kullanici_sifre=md5($oldpass);

  $kullanicisor=$db->prepare("SELECT * FROM kullanicilar WHERE kullanici_sifre=:sifre AND kullanici_id=:id");
  $kullanicisor->execute(array(
   'id' => securetext($_POST['kullanici_id']),
   'sifre' => $kullanici_sifre
 ));

  $say=$kullanicisor->rowCount();

  if ($say==0) {
   header("Location:../profil.php?status=error");
 } else {
   if ($newpass1==$newpass2) {
    if (strlen($newpass1)>=6) {
     $sifre=md5($newpass1);
     $kullanicikaydet=$db->prepare("UPDATE kullanicilar SET
      kullanici_sifre=:kullanici_sifre
      WHERE kullanici_id=:kullanici_id");

     $insert=$kullanicikaydet->execute(array(
      'kullanici_sifre' => $sifre,
      'kullanici_id'=>securetext($_POST['kullanici_id'])
    ));

     if ($insert) {
      header("Location:../profil.php?status=success");

    } else {
      header("Location:../profil.php?status=error");
    }


  } else {
   header("Location:../profil.php?status=error");
 }

} else {
header("Location:../profil?status=error");
exit;
}
}
exit;
if ($update) {
header("Location:../profil?durum=ok");

} else {
header("Location:../profil?durum=no");
}
}



/* ************************************************************************************************************* */



if (isset($_POST['profil'])) {

  if (isset($_SESSION['kullanici_mail'])) {

  if ($_FILES['kullanici_resim']["size"] > 0) {
 
    $uploads_dir = '../assets/img';
    @$tmp_name = $_FILES['kullanici_resim']["tmp_name"];
    $name = $_FILES['kullanici_resim']["name"];
    $benzersizsayi1=rand(20000,32000);
    $benzersizsayi2=rand(20000,32000);
    $benzersizsayi3=rand(20000,32000);
    $benzersizsayi4=rand(20000,32000);
    $benzersizad=$benzersizsayi1.$benzersizsayi2.$benzersizsayi3.$benzersizsayi4;
    $imgyolx=substr($uploads_dir, 3)."/".$benzersizad.$name;
    @move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$name");
 
    $kullaniciquery = $db->prepare("UPDATE kullanicilar SET
    kullanici_resim = :kullanici_resim
    WHERE kullanici_id={$_POST['kullanici_id']}");
  $insert = $kullaniciquery->execute(array(
    "kullanici_resim" => $imgyolx
  ));
 
    $kullaniciquery = $db->prepare("UPDATE kullanicilar SET
    kullanici_isim = :kullanici_isim,
    kullanici_mail = :kullanici_mail
    WHERE kullanici_id={$_POST['kullanici_id']}");
  $insert = $kullaniciquery->execute(array(
    "kullanici_isim" => securetext($_POST['kullanici_isim']),
    "kullanici_mail" => securetext($_POST['kullanici_mail'])
  ));
  
  if ( $insert ){
      $resimsil=$_POST['kullanici_resim'];
       unlink("../$resimsil");
 
       session_start();
       session_destroy();
       header("Location: ../giris.php");
  } else {
      header("Location: ../profil.php?status=error");
  }
 
    
 /* Eğer Resimde Değişiklik Yoksa Sadece Yazılar Güncellensin Diye Burası Var (Alt Taraf) */
  } else {
    $kullaniciquery = $db->prepare("UPDATE kullanicilar SET
    kullanici_isim = :kullanici_isim,
    kullanici_mail = :kullanici_mail
    WHERE kullanici_id={$_POST['kullanici_id']}");
  $insert = $kullaniciquery->execute(array(
    "kullanici_isim" => securetext($_POST['kullanici_isim']),
    "kullanici_mail" => securetext($_POST['kullanici_mail'])
  ));
  if ( $insert ){
    session_start();
    session_destroy();
    header("Location: ../giris.php");
  } else {
      header("Location: ../resimler.php?status=error");
  }
  
 }
 
 }

 }
 
 

/* ************************************************************************************************************* */


if (isset($_POST['hizmetlerimizbaslik'])) {

  $ilavequery = $db->prepare("UPDATE ilaveler SET
    ilaveler_hizmetlerimiz_baslik = :ilaveler_hizmetlerimiz_baslik
    WHERE ilaveler_id=1");
  $insert = $ilavequery->execute(array(
    "ilaveler_hizmetlerimiz_baslik" => securetext($_POST['ilaveler_hizmetlerimiz_baslik'])
  ));
  if ( $insert ){
      header("Location: ../hizmetlerimiz-baslik.php?status=success");
  } else {
      header("Location: ../hizmetlerimiz-baslik.php?status=error");
  }

}



if (isset($_POST['takimimizbaslik'])) {

  $ilavequery = $db->prepare("UPDATE ilaveler SET
    ilaveler_takimimiz_baslik = :ilaveler_takimimiz_baslik
    WHERE ilaveler_id=1");
  $insert = $ilavequery->execute(array(
    "ilaveler_takimimiz_baslik" => securetext($_POST['ilaveler_takimimiz_baslik'])
  ));
  if ( $insert ){
      header("Location: ../takimimiz-baslik.php?status=success");
  } else {
      header("Location: ../takimimiz-baslik.php?status=error");
  }

}





if (isset($_POST['portfoybaslik'])) {

  $ilavequery = $db->prepare("UPDATE ilaveler SET
    ilaveler_portfoy_baslik = :ilaveler_portfoy_baslik
    WHERE ilaveler_id=1");
  $insert = $ilavequery->execute(array(
    "ilaveler_portfoy_baslik" => securetext($_POST['ilaveler_portfoy_baslik'])
  ));
  if ( $insert ){
      header("Location: ../portfoy-baslik.php?status=success");
  } else {
      header("Location: ../portfoy-baslik.php?status=error");
  }

}

?>