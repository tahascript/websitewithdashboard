<?php include "header.php"; ?>
<?php

if (isset($_POST['mesajgoruntule'])) {
	if (is_numeric($_POST['id'])) {

		$formquery=$db->prepare("SELECT * FROM form where id=:id");
		$formquery->execute(array(
			'id' => $_POST['id']
		));
		$form=$formquery->fetch(PDO::FETCH_ASSOC);
	} else {
		header("location:gelen-kutusu.php");
	}

} else {
	header("location:gelen-kutusu.php");
} 

?>
<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Mesaj Görüntüleme </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Mesaj Görüntüleme</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Mesaj İçeriği</h5>
                                <div class="card-body">
                                    <form enctype="multipart/form-data">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Ad Soyad</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input disabled type="text" name="adsoyad" value="<?php echo $form['adsoyad'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">E-posta</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input disabled type="text" name="eposta" value="<?php echo $form['eposta'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Konu</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input disabled type="text" name="konu" value="<?php echo $form['konu'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Mesaj</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <textarea disabled class="ckeditor" id="editor1" name="mesaj"><?php echo $form['mesaj'] ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <a href="gelen-kutusu.php" class="btn btn-space btn-primary">Geri Git </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>