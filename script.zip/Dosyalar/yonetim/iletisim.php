<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>

<?php
$iletisimquery=$db->prepare("SELECT * FROM iletisim");
$iletisimquery->execute(array(0));
$iletisim=$iletisimquery->fetch(PDO::FETCH_ASSOC);
?>

<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">İletişim İçerik </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">İletişim</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">İletişim İçerik</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">İletişim Düzenle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İletişim Başlık</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="iletisim_baslik" value="<?php echo $iletisim['iletisim_baslik'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İletişim Harita</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="iletisim_harita" placeholder="https://www.google.com/maps/embed?..." value="<?php echo $iletisim['iletisim_harita'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İletişim Telefon</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <textarea class="ckeditor" id="editor1" name="iletisim_telefon"><?php echo $iletisim['iletisim_telefon'] ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İletişim Mail</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <textarea class="ckeditor" id="editor1" name="iletisim_mail"><?php echo $iletisim['iletisim_mail'] ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İletişim Adres</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <textarea class="ckeditor" id="editor1" name="iletisim_adres"><?php echo $iletisim['iletisim_adres'] ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="iletisim" type="submit" class="btn btn-space btn-primary">Kaydet</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>