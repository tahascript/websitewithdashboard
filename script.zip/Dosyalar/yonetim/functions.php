<?php
/*

████████╗ █████╗ ██╗  ██╗ █████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗           ███╗   ██╗███████╗████████╗
╚══██╔══╝██╔══██╗██║  ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝           ████╗  ██║██╔════╝╚══██╔══╝
   ██║   ███████║███████║███████║███████╗██║     ██████╔╝██║██████╔╝   ██║              ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══██║██╔══██║██╔══██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║              ██║╚██╗██║██╔══╝     ██║   
   ██║   ██║  ██║██║  ██║██║  ██║███████║╚██████╗██║  ██║██║██║        ██║       ██╗    ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝       ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   

    Bu Yazılım, TahaScript.net Tarafından Yapılmıştır Ve Ücretsiz Olarak Yayınlanmıştır

    www.tahascript.net
*/




function sessionkontrol() {
	if (empty($_SESSION['kullanici_mail'])) {
        header("Location: giris.php");
        exit();
	}
}
function sessionkontrol2() {
	if (isset($_SESSION['kullanici_mail'])) {
        header("Location: index.php");
        exit();
	}
}


function copyright() {
        $x="PCEtLQoKCuKWiOKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVlyDilojilojilojilojilojilZcg4paI4paI4pWXICDilojilojilZcg4paI4paI4paI4paI4paI4pWXIOKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVlyDilojilojilojilojilojilojilZfilojilojilojilojilojilojilZcg4paI4paI4pWX4paI4paI4paI4paI4paI4paI4pWXIOKWiOKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVlyAgICAgICAgICAg4paI4paI4paI4pWXICAg4paI4paI4pWX4paI4paI4paI4paI4paI4paI4paI4pWX4paI4paI4paI4paI4paI4paI4paI4paI4pWXCuKVmuKVkOKVkOKWiOKWiOKVlOKVkOKVkOKVneKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVl+KWiOKWiOKVkSAg4paI4paI4pWR4paI4paI4pWU4pWQ4pWQ4paI4paI4pWX4paI4paI4pWU4pWQ4pWQ4pWQ4pWQ4pWd4paI4paI4pWU4pWQ4pWQ4pWQ4pWQ4pWd4paI4paI4pWU4pWQ4pWQ4paI4paI4pWX4paI4paI4pWR4paI4paI4pWU4pWQ4pWQ4paI4paI4pWX4pWa4pWQ4pWQ4paI4paI4pWU4pWQ4pWQ4pWdICAgICAgICAgICDilojilojilojilojilZcgIOKWiOKWiOKVkeKWiOKWiOKVlOKVkOKVkOKVkOKVkOKVneKVmuKVkOKVkOKWiOKWiOKVlOKVkOKVkOKVnQogICDilojilojilZEgICDilojilojilojilojilojilojilojilZHilojilojilojilojilojilojilojilZHilojilojilojilojilojilojilojilZHilojilojilojilojilojilojilojilZfilojilojilZEgICAgIOKWiOKWiOKWiOKWiOKWiOKWiOKVlOKVneKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKWiOKVlOKVnSAgIOKWiOKWiOKVkSAgICAgICAgICAgICAg4paI4paI4pWU4paI4paI4pWXIOKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKVlyAgICAg4paI4paI4pWRICAgCiAgIOKWiOKWiOKVkSAgIOKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVkeKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVkeKWiOKWiOKVlOKVkOKVkOKWiOKWiOKVkeKVmuKVkOKVkOKVkOKVkOKWiOKWiOKVkeKWiOKWiOKVkSAgICAg4paI4paI4pWU4pWQ4pWQ4paI4paI4pWX4paI4paI4pWR4paI4paI4pWU4pWQ4pWQ4pWQ4pWdICAgIOKWiOKWiOKVkSAgICAgICAgICAgICAg4paI4paI4pWR4pWa4paI4paI4pWX4paI4paI4pWR4paI4paI4pWU4pWQ4pWQ4pWdICAgICDilojilojilZEgICAKICAg4paI4paI4pWRICAg4paI4paI4pWRICDilojilojilZHilojilojilZEgIOKWiOKWiOKVkeKWiOKWiOKVkSAg4paI4paI4pWR4paI4paI4paI4paI4paI4paI4paI4pWR4pWa4paI4paI4paI4paI4paI4paI4pWX4paI4paI4pWRICDilojilojilZHilojilojilZHilojilojilZEgICAgICAgIOKWiOKWiOKVkSAgICAgICDilojilojilZcgICAg4paI4paI4pWRIOKVmuKWiOKWiOKWiOKWiOKVkeKWiOKWiOKWiOKWiOKWiOKWiOKWiOKVlyAgIOKWiOKWiOKVkSAgIAogICDilZrilZDilZ0gICDilZrilZDilZ0gIOKVmuKVkOKVneKVmuKVkOKVnSAg4pWa4pWQ4pWd4pWa4pWQ4pWdICDilZrilZDilZ3ilZrilZDilZDilZDilZDilZDilZDilZ0g4pWa4pWQ4pWQ4pWQ4pWQ4pWQ4pWd4pWa4pWQ4pWdICDilZrilZDilZ3ilZrilZDilZ3ilZrilZDilZ0gICAgICAgIOKVmuKVkOKVnSAgICAgICDilZrilZDilZ0gICAg4pWa4pWQ4pWdICDilZrilZDilZDilZDilZ3ilZrilZDilZDilZDilZDilZDilZDilZ0gICDilZrilZDilZ0gICAKCiAgICBCdSBZYXrEsWzEsW0sIFRhaGFTY3JpcHQubmV0IFRhcmFmxLFuZGFuIFlhcMSxbG3EscWfdMSxciBWZSDDnGNyZXRzaXogT2xhcmFrIFlhecSxbmxhbm3EscWfdMSxcgoKICAgIHd3dy50YWhhc2NyaXB0Lm5ldAoKCi0tPg==";
        echo base64_decode($x);
}

	



?>