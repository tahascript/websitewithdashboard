<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>
<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Kişi Ekle </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Takımımız</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Kişi Ekle</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Kişi Ekle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" name="takimimiz_resim" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Ad Soyad</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_adsoyad" placeholder="örn: Ahmet Mehmet" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Rolü</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_rol" placeholder="örn: Temizlikçi" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Sıra</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_sira" placeholder="örn: 1" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Facebook</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_facebook" value="https://www.facebook.com/" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Twitter</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_twitter" value="https://www.twitter.com/" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">İnstagram</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="takimimiz_instagram" value="https://www.instagram.com/" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="kisiekle" type="submit" class="btn btn-space btn-primary">Ekle</button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>