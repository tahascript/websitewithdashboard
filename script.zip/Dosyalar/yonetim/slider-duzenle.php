<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>

<?php
if (isset($_POST['slider_id'])) {
	$sliderquery=$db->prepare("SELECT * FROM slider where slider_id=:id");
	$sliderquery->execute(array(
		'id' => $_POST['slider_id']
	));
	$sliderlar=$sliderquery->fetch(PDO::FETCH_ASSOC);
} else {
	header("Location: sliderlar.php");
} 
?>

<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Slider Düzenle </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Slider</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Slider Düzenle</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Slider Düzenle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" class="form-control" name="slider_resim" value="<?php echo $sliderlar['slider_resim'] ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Seçili Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <div class="m-r-10"><img src="<?php echo '../'.$sliderlar['slider_resim'] ?>" class="rounded" width="100"></div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" name="slider_resim" class="form-control">
                                            </div>
                                        </div>
                                        <input type="hidden" class="form-control" name="slider_resim" value="<?php echo $_POST['slider_resim'] ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Başlık</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="slider_h2" value="<?php echo $sliderlar['slider_h2'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Ana Başlık</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="slider_h1" value="<?php echo $sliderlar['slider_h1'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Buton Başlık</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="slider_buton_baslik" value="<?php echo $sliderlar['slider_buton_baslik'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Buton Link</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="slider_buton_link" value="<?php echo $sliderlar['slider_buton_link'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Slider Sıra</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="slider_sira" value="<?php echo $sliderlar['slider_sira'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <input type="hidden" class="form-control" name="slider_id" value="<?php echo $_POST['slider_id'] ?>">
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="sliderduzenle" type="submit" class="btn btn-space btn-primary">Kaydet</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>