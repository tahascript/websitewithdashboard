<?php include "header.php"; ?>
<?php include "inc/dbconnect.php"; ?>

<?php
if (isset($_POST['portfoy_id'])) {
	$resimquery=$db->prepare("SELECT * FROM portfoy where portfoy_id=:id");
	$resimquery->execute(array(
		'id' => $_POST['portfoy_id']
	));
	$resimler=$resimquery->fetch(PDO::FETCH_ASSOC);
} else {
	header("Location: resimler.php");
} 
?>

<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Resim Düzenle </h2>
                            <p class="pageheader-text"></p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kontrol Paneli</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Portföy</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Resim Düzenle</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
             
                    
                    
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Kişi Düzenle</h5>
                                <div class="card-body">
                                    <form action="inc/process.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" class="form-control" name="portfoy_resim" value="<?php echo $resimler['portfoy_resim'] ?>">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Seçili Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <div class="m-r-10"><img src="<?php echo '../'.$resimler['portfoy_resim'] ?>" class="rounded" width="100"></div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Resim</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" name="portfoy_resim" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Ad Soyad</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="portfoy_baslik" value="<?php echo $resimler['portfoy_baslik'] ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Rolü</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="portfoy_aciklama" value="<?php echo $resimler['portfoy_aciklama'] ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Kişi Sıra</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" name="portfoy_sira" value="<?php echo $resimler['portfoy_sira'] ?>" class="form-control">
                                            </div>
                                        </div>

                                        <input type="hidden" class="form-control" name="portfoy_id" value="<?php echo $_POST['portfoy_id'] ?>">
                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button name="resimduzenle" type="submit" class="btn btn-space btn-primary">Kaydet</button>
                                            </div>
                                        </div>
</form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
           
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    <?php include "footer.php"; ?>