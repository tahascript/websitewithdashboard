
  <!-- Start Footer bottom Area -->
<?php
$footersor=$db->prepare("SELECT * FROM altbilgi");
$footersor->execute(array(0));
$footer=$footersor->fetch(PDO::FETCH_ASSOC);
?>

  <footer>
    <div class="footer-area">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                <img style="width: 50%; height: auto;" src="<?php echo $footer['altbilgi_resim']; ?>" alt="footer-logo">
                </div>
                <p><?php echo $footer['altbilgi_icerik']; ?></p>
                <div class="footer-icons">
                  <ul>
                    <li>
                      <a href="<?php echo $footer['altbilgi_facebook']; ?>"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                      <a href="<?php echo $footer['altbilgi_twitter']; ?>"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                      <a href="<?php echo $footer['altbilgi_instagram ']; ?>"><i class="fa fa-instagram"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
              <p>
              <?php echo $footer['altbilgi_vizyon']; ?>
              </p>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
              <p>
              <?php echo $footer['altbilgi_misyon']; ?>
              </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
              Copyright &copy; 2019 <a href="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>"><?php echo $ayarlar['site_sahip']; ?></a>
              </p>
            </div>
            <div class="credits">
              <!--
                All the links in the footer should remain intact.
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=eBusiness
              -->
              Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/knob/jquery.knob.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <script src="lib/appear/jquery.appear.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>

  <script src="yonetim/assets/sweetalert2/sweetalert2.all.min.js"></script>

  <script src="js/main.js"></script>
  <script>
    // MDB Lightbox Init
    $(function () {
    $("#mdb-lightbox-ui").load("mdb-addons/mdb-lightbox-ui.html");
    });
  </script>
</body>

</html>


<?php if (@$_GET['status'] == "success") { ?>
<script>
Swal.fire({
  type: 'success',
  title: 'İşlem Başarılı',
  showConfirmButton: false,
  timer: 2000
})
</script>
<?php } else if (@$_GET['status'] == "error") { ?>
<script>
Swal.fire({
  type: 'error',
  title: 'Ters Giden Bir Şeyler Var!',
  showConfirmButton: false,
  timer: 2000
})

</script>
<?php } ?>