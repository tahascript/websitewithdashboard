<?php
/*

████████╗ █████╗ ██╗  ██╗ █████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗           ███╗   ██╗███████╗████████╗
╚══██╔══╝██╔══██╗██║  ██║██╔══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝           ████╗  ██║██╔════╝╚══██╔══╝
   ██║   ███████║███████║███████║███████╗██║     ██████╔╝██║██████╔╝   ██║              ██╔██╗ ██║█████╗     ██║   
   ██║   ██╔══██║██╔══██║██╔══██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║              ██║╚██╗██║██╔══╝     ██║   
   ██║   ██║  ██║██║  ██║██║  ██║███████║╚██████╗██║  ██║██║██║        ██║       ██╗    ██║ ╚████║███████╗   ██║   
   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝       ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   

    Bu Yazılım, TahaScript.net Tarafından Yapılmıştır Ve Ücretsiz Olarak Yayınlanmıştır

    www.tahascript.net
*/

include "header.php"; ?>


  <!-- Start Slider Area -->
  
  <div id="home" class="slider-area">
    <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides">
        <?php
        $sliderresimrakam=1;
        $sliderresimsor=$db->prepare("SELECT * FROM slider ORDER BY slider_sira ASC");
        $sliderresimsor->execute();
        while ($sliderresim=$sliderresimsor->fetch(PDO::FETCH_ASSOC)) { $sliderresimrakam++; ?>
        <img src="<?php echo $sliderresim['slider_resim']; ?>" alt="" title="#slider-direction-<?php echo $sliderresimrakam; ?>" />
        <?php } ?>
      </div>

      <?php
        $sliderrakam=1;
        $slidersor=$db->prepare("SELECT * FROM slider ORDER BY slider_sira ASC");
        $slidersor->execute();
        while ($slider=$slidersor->fetch(PDO::FETCH_ASSOC)) { $sliderrakam++; ?>
      <!-- direction 1 -->
      <div id="slider-direction-<?php echo $sliderrakam; ?>" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="slider-content">
                <!-- layer 1 -->
                <div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
                  <h2 class="title1"><?php echo $slider['slider_h2']; ?> </h2>
                </div>
                <!-- layer 2 -->
                <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                  <h1 class="title2"><?php echo $slider['slider_h1']; ?></h1>
                </div>
                <!-- layer 3 -->
                <div class="layer-1-3 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                  <a class="ready-btn right-btn page-scroll" href="<?php echo $slider['slider_buton_link']; ?>"><?php echo $slider['slider_buton_baslik']; ?></a>
                  <!-- <a class="ready-btn page-scroll" href="#about">Learn More</a> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>

  <!-- Start About area -->
  <?php
  $hakkimizdacek=$db->prepare("SELECT * FROM hakkimizda");
  $hakkimizdacek->execute(array(0));
  $hakkimizda=$hakkimizdacek->fetch(PDO::FETCH_ASSOC); 
  ?>
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2><?php echo $hakkimizda['hakkimizda_baslik'] ?></h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start-->
            

        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="<?php echo $hakkimizda['hakkimizda_resim'] ?>" alt="">
								</a>
            </div>
          </div>
        </div>
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">

            <?php echo $hakkimizda['hakkimizda_icerik']; ?>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
  <!-- End About area -->

  <!-- Start Service area -->
  <?php
  $ilavelersor=$db->prepare("SELECT * FROM ilaveler");
  $ilavelersor->execute(array(0));
  $ilaveler=$ilavelersor->fetch(PDO::FETCH_ASSOC); 
  ?>
  <div id="services" class="services-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline services-head text-center">
            <h2><?php echo $ilaveler['ilaveler_hizmetlerimiz_baslik']; ?></h2>
          </div>
        </div>
      </div>
      <div class="row text-center">
        <div class="services-contents">
          <!-- Start Left services -->
          <?php
          $hizmetrakam=1;
          $hizmetsor=$db->prepare("SELECT * FROM hizmetlerimiz");
          $hizmetsor->execute();
          while ($hizmetlerimiz=$hizmetsor->fetch(PDO::FETCH_ASSOC)) { $hizmetrakam++; ?>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
											<i class="<?php echo $hizmetlerimiz['hizmetlerimiz_icon']; ?>"></i>
										</a>
                  <h4><?php echo $hizmetlerimiz['hizmetlerimiz_baslik']; ?></h4>
                  <p>
                  <?php echo $hizmetlerimiz['hizmetlerimiz_icerik']; ?>
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <!-- End Service area -->




  <!-- Start team Area -->
  <div id="team" class="our-team-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2><?php echo $ilaveler['ilaveler_takimimiz_baslik']; ?></h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="team-top">
        <?php
        $takimimizrakam=1;
        $takimimizsor=$db->prepare("SELECT * FROM takimimiz");
        $takimimizsor->execute();
        while ($takimimiz=$takimimizsor->fetch(PDO::FETCH_ASSOC)) { $takimimizrakam++; ?>

          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="single-team-member">
              <div class="team-img">
                <a href="#">
										<img src="<?php echo $takimimiz['takimimiz_resim']; ?>" alt="">
									</a>
                <div class="team-social-icon text-center">
                  <ul>
                    <li>
                      <a href="<?php echo $takimimiz['takimimiz_facebook']; ?>">
													<i class="fa fa-facebook"></i>
												</a>
                    </li>
                    <li>
                      <a href="<?php echo $takimimiz['takimimiz_twitter']; ?>">
													<i class="fa fa-twitter"></i>
												</a>
                    </li>
                    <li>
                      <a href="<?php echo $takimimiz['takimimiz_instagram']; ?>">
													<i class="fa fa-instagram"></i>
												</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="team-content text-center">
                <h4><?php echo $takimimiz['takimimiz_adsoyad']; ?></h4>
                <p><?php echo $takimimiz['takimimiz_rol']; ?></p>
              </div>
            </div>
          </div>
          <?php } ?>
          <!-- End column -->
        </div>
      </div>
    </div>
  </div>
  <!-- End Team Area -->



  <!-- Start portfolio Area -->
  <div id="portfolio" class="portfolio-area area-padding fix">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2><?php echo $ilaveler['ilaveler_portfoy_baslik']; ?></h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- Start Portfolio -page -->
        
        <div class="awesome-project-content">
        <?php
        $portfoyrakam=1;
        $portfoysor=$db->prepare("SELECT * FROM portfoy");
        $portfoysor->execute();
        while ($portfoy=$portfoysor->fetch(PDO::FETCH_ASSOC)) { $portfoyrakam++; ?>
          <!-- single-awesome-project start -->
          <div class="col-md-4 col-sm-4 col-xs-12 design development">
            <div class="single-awesome-project">
              <div class="awesome-img">
                <a href="#"><img src="<?php echo $portfoy['portfoy_resim'] ?>" alt="" /></a>
                <div class="add-actions text-center">
                  <div class="project-dec">
                    <a class="venobox" data-gall="myGallery" href="<?php echo $portfoy['portfoy_resim'] ?>">
                      <h4><?php echo $portfoy['portfoy_baslik'] ?></h4>
                      <span><?php echo $portfoy['portfoy_aciklama'] ?></span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- single-awesome-project end -->
        <?php } ?>

        </div>
      </div>
    </div>
  </div>
  <!-- awesome-portfolio end -->
  
  <!-- Start contact Area -->
  <?php
  $iletisimsor=$db->prepare("SELECT * FROM iletisim");
  $iletisimsor->execute(array(0));
  $iletisim=$iletisimsor->fetch(PDO::FETCH_ASSOC);
  ?>
  <div id="contact" class="contact-area">
    <div class="contact-inner area-padding">
      <div class="contact-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2><?php echo $iletisim['iletisim_baslik']; ?></h2>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-mobile"></i>
                <p>
                  <?php echo $iletisim['iletisim_telefon']; ?>
                </p>
              </div>
            </div>  
          </div>
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-envelope-o"></i>
                <p>
                  <?php echo $iletisim['iletisim_mail']; ?>
                </p>
              </div>
            </div>
          </div>
          <!-- Start contact icon column -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="contact-icon text-center">
              <div class="single-icon">
                <i class="fa fa-map-marker"></i>
                <p>
                  <?php echo $iletisim['iletisim_adres']; ?>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">

          <!-- Start Google Map -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <!-- Start Map -->
            <iframe src="<?php echo $iletisim['iletisim_harita']; ?>" width="100%" height="380" frameborder="0" style="border:0" allowfullscreen></iframe>
            <!-- End Map -->
          </div>
          <!-- End Google Map -->

          <!-- Start  contact -->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="form contact-form">
              <div id="sendmessage"></div>
              <div id="errormessage"></div>


              <form action="gonder.php" method="POST" role="form" class="contactForm">
                <div class="form-group">
                  <input type="text" class="form-control" name="adsoyad" placeholder="Ad Soyad">
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="eposta" placeholder="E-posta">
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="konu" placeholder="Konu">
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" name="mesaj" placeholder="Mesajınız"></textarea>
                  <div class="validation"></div>
                </div>
                <div class="text-center"><button type="submit" name="form" >Gönder</button></div>
              </form>


            </div>
          </div>
          <!-- End Left contact -->
        </div>
      </div>
    </div>
  </div>
  <!-- End Contact Area -->
<?php include "footer.php"; ?>

